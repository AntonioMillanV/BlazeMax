﻿using System;

namespace BlazeMaxControls.Helpers
{
    public class ComboEnumWrapper
    {
        public Enum Type { get; set; }

        public string DisplayText { get; set; }
    }
}
